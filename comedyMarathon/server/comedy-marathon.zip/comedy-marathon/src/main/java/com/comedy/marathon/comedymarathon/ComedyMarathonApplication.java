package com.comedy.marathon.comedymarathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComedyMarathonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComedyMarathonApplication.class, args);
	}

}
