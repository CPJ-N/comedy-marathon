package com.comedy.marathon.comedymarathon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComedyMarathonApplicationTests {

	@Test
	void contextLoads() {
	}

}
